function openNav{

	document.getElementById('nav').style.display= 'block';
}

function closeNav(){
	document.getElementById('nav').style.display= 'none';
}

function slider(){
	var active= {0,1};
	var card= document.getElementsByClassName('card');
	for(var i=0; i<card.length; i++){
		for(var j=0; j<active.lengthl j++){
			
		}
	}
	
}